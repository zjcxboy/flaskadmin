# sqlalchemy的配置参数
SQLALCHEMY_DATABASE_URI = "mysql://root:1234567@127.0.0.1:3306/flaskadmin"
# 设置sqlalchemy自动更跟踪数据库
SQLALCHEMY_TRACK_MODIFICATIONS = True
SQLALCHEMY_COMMIT_TEARDOWN = True

SECRET_KEY = "doiso7fd89fyd9^(fsd"
DEBUG = True

BABEL_DEFAULT_LOCALE = 'zh_Hans_CN'

# UPLOAD_FOLDER = 'F:\\uploadFile'
MAX_CONTENT_LENGTH = 16 * 1024 * 1024

