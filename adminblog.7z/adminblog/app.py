from flask import Flask
import config
# app = Flask(__name__,static_folder="apps/static",static_url_path="/apps/static",template_folder='apps/templates')
app = Flask(__name__)
app.config.from_object(config)

# from flask_babelex import Babel
# babel = Babel(app)
#
# from apps.blog import blog
# app.register_blueprint(blog)

from apps.models import getDB
db=getDB()
db.init_app(app)

from flask_admin import Admin
# from flask_admin.contrib.sqla import ModelView
from apps.models import User,Article,Tag
from apps.BaseModelview import UserAdmin,ArticleAdmin,TagAdmin

# admin = Admin(app, name='后台管理系统', template_mode='bootstrap3',base_template='admin/mybase.html')
admin = Admin(app, name='后台管理系统', template_mode='bootstrap3')
admin.add_view(UserAdmin(User, db.session,name=u'用户管理'))
admin.add_view(ArticleAdmin(Article, db.session,name=u'文章管理'))
admin.add_view(TagAdmin(Tag, db.session,name=u'标签管理'))

if __name__ == '__main__':

    app.run()
