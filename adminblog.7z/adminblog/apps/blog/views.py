from flask import request,url_for,redirect
from . import blog
from apps.models import User,getDB

db=getDB()
@blog.route('/index')
def index():
    return 'Hello this is blog page!'

# @blog.route('/')
# def indexinit():
#     return redirect(url_for('blog.index'))

@blog.route('/adduser')
def addUser():
    admin=User('admin','admin@qq.com')
    db.session.add(admin)
    db.session.commit()
    return 'success'