from flask_admin.contrib.sqla import ModelView
from wtforms.widgets import TextArea
from sqlalchemy.event import listens_for
import os.path as op
import  os
from jinja2 import Markup
from flask import url_for
from flask_admin import form,expose
from apps.models import User
from wtforms import TextAreaField




class BaseModelview(ModelView):
    def getinfo(self):
        return "this is another model"

file_path = op.join(op.dirname(__file__), 'static') # 文件上传路径

class UserAdmin(BaseModelview):
    column_labels = {
        'id': u'序号',
        'email': u'邮件',
        'username': u'用户名',
        'role': u'角色',
        'password_hash': u'密码',
        'head_img': u'头像',
        'create_time':u'创建时间'

    }
    column_exclude_list = ['password_hash', ]
    # 要使列可搜索，或使用它们进行过滤，请指定列名称的列表
    column_searchable_list = ['username', 'email']
    # 要获得更快的编辑体验，请在列表视图中启用内嵌编辑：
    column_editable_list = ['username', 'email']
    # 设置CURD的选项
    # can_create = False
    # can_edit = False
    # can_delete = False
    # 实现csv导出功能参数
    can_export = True
    # 设置缩略图的
    def _list_thumbnail(view, context, model, name):
        if not model.head_img:
            return ''
        return Markup('<img src="%s">' % url_for('static',
                                                 filename=form.thumbgen_filename(model.head_img)))

    # 格式化列表的图像显示
    column_formatters = {
        'head_img': _list_thumbnail
    }

    # 扩展列表显示的头像为60*60像素
    form_extra_fields = {
        'head_img': form.ImageUploadField('Image',
                                          base_path=file_path,
                                          relative_path='uploadFile/',
                                          thumbnail_size=(60, 60, True))
    }

@listens_for(User, 'after_delete')

def del_image(mapper, connection, target):
    if target.head_img:
        # Delete image
        try:
            os.remove(op.join(file_path, target.head_img))
        except OSError:
            pass
        # Delete thumbnail
        try:
            os.remove(op.join(file_path,
            form.thumbgen_filename(target.head_img)))
        except OSError:
            pass


class CKTextAreaWidget(TextArea):
    def __call__(self, field, **kwargs):
        if kwargs.get('class'):
            kwargs['class'] += ' ckeditor'
        else:
            kwargs.setdefault('class', 'ckeditor')
        return super(CKTextAreaWidget, self).__call__(field, **kwargs)

class CKTextAreaField(TextAreaField):
    widget = CKTextAreaWidget()
class ArticleAdmin(BaseModelview):
    extra_js = ['//cdn.ckeditor.com/4.6.0/standard/ckeditor.js']

    form_overrides = {
        'content': CKTextAreaField
    }
    column_labels = {
        'id': u'序号',
        'title': u'标题',
        'content': u'内容',
        'tag': u'标签',
        'create_time': u'创建时间'
    }
column_exclude_list = ['content', ]
class TagAdmin(BaseModelview):
    column_labels = {
        'id': u'序号',
        'name': u'标签',
        'desc': u'描述',
        'create_time': u'创建时间'
    }
